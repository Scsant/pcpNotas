import "./styles.css";

import { Desktop1 } from "./Desktop1/Desktop1";

export default function App() {
  return (
    <div>
      <Desktop1 />
    </div>
  );
}
